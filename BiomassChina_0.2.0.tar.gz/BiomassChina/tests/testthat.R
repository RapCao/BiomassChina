library(testthat)
library(xlsx)
library(BiomassChina)

test_check("BiomassChina")
